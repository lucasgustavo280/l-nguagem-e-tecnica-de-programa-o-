#include <stdio.h>
#include <stdlib.h>


int main() {
 
  float e_v, e_r1, e_r2, s_it, s_vr1, s_vr2, s_req,s_ir1,s_ir2;

  scanf("%f", &e_v);
  scanf("%f",& e_r1);
  scanf("%f",& e_r2);
  
  s_req=((e_r1*e_r2)/(e_r1+e_r2));
  s_it= e_v/(s_req);
  s_vr1= s_it*e_r1;
  s_vr2= s_it*e_r2;
  s_ir1= e_v/e_r1;
  s_ir2= e_v/e_r2;

  printf("corrente total:%f\n",s_it);
  printf("tensão de r1:%f\n",s_vr1);
  printf("tensão de r2:%f\n",s_vr2);
  printf("tensão da fonte:%f\n",e_v);;
  printf("REQ :%f\n",s_req);
  printf("corrente de r1:%f\n",s_ir1);
  printf("corrente de r1:%f\n",s_ir2);


  return 0;
}