
//cálculo área do quadrado
#include <stdio.h>
#include <stdlib.h>

int main()
{
  float e_lateral1, e_lateral2,s_area;

  scanf("%f",&e_lateral1);
  scanf("%f",&e_lateral2);

  s_area= e_lateral1*e_lateral2;

printf("area do quadrado:%f\n",s_area);

return 0;

}

