
//cálculo área do retângulo
#include <stdio.h>
#include <stdlib.h>

int main()
{
  float e_lat1, e_lat2,s_area;

  scanf("%f",&e_lat1);
  scanf("%f",&e_lat2);

  s_area= e_lat1*e_lat2;

printf("area do retângulo:%f\n",s_area);

return 0;

}
